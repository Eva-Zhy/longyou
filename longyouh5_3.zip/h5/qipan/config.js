// next 0 上 1 右 2 下 3左
window.gezhi=[
    // 1
    {
        top:17,
        left:19,
        type:0,
        next:3
    },
    // 2
    {
        top:-2,
        left:55,
        type:0,
        next:3
    },
    // 3
    {
        top:-20,
        left:90,
        type:0,
        next:2
    },
    // 4
    {
        top:0,
        left:125,
        type:1,
        next:3
    },
    // 5
    {
        top:-19,
        left:160,
        type:0,
        next:2
    },
    // 6
    {
        top:0,
        left:195,
        type:0,
        next:2
    },
    // 7
    {
        top:-19,
        left:230,
        type:0,
        next:2
    },
    // 8
    {
        top:0,
        left:265,
        type:0,
        next:2
    },
    // 9
    {
        top:17,
        left:300,
        type:1,
        next:2
    },
    // 10
    {
        top:35,
        left:265,
        type:0,
        next:2
    },
    // 11
    {
        top:55,
        left:231,
        type:0,
        next:2
    },
    // 12
    {
        top:73,
        left:265,
        type:0,
        next:2
    },
    // 13
    {
        top:90,
        left:300,
        type:1,
        next:2
    },
    // 14
    {
        top:108,
        left:266,
        type:0,
        next:2
    },
    // 15
    {
        top:126,
        left:231,
        type:0,
        next:2
    },
    // 16
    {
        top:108,
        left:195,
        type:0,
        next:2
    },
    // 17
    {
        top:126,
        left:161,
        type:0,
        next:2
    },
    // 18
    {
        top:109,
        left:126,
        type:0,
        next:2
    },
    // 19
    {
        top:126,
        left:91,
        type:0,
        next:2
    },
    // 20
    {
        top:107,
        left:56,
        type:0,
        next:2
    },
    // 21
    {
        top:88,
        left:22,
        type:0,
        next:2
    },
    // 22
    {
        top:70,
        left:57,
        type:1,
        next:2
    },
    // 23
    {
        top:52,
        left:90,
        type:0,
        next:2
    },
    // 24
    {
        top:34,
        left:55,
        type:0,
        next:2
    }

]